
const mysql = require('mysql2');
const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');
const db = mysql.createConnection('mysql://gunjan:AVNS_wd9IdbWmOotZWRgGM9A@digispecs-db-mitwpu-3f06.j.aivencloud.com:20485/my_gaming_db');
app.use(express.json()); // or app.use(bodyParser.json());

db.connect((err) => {
    if (err) {
        console.error('Error connecting to database:', err);
        return;
    }
    console.log('Connected to the database');
});

// // Example query
// db.query('SELECT * FROM public.laptopBrand', (err, results) => {
//     if (err) {
//         console.error('Error fetching data:', err);
//         return;
//     }
//     console.log('Data fetched:', results);
// });

module.exports = db;
const digiRoutes = require('./digiRoutes');
app.use(cors());
app.use('/api', digiRoutes); // Mount the routes at the /api path

app.listen(3000, () => {
    console.log('Server running on port 3000');
});