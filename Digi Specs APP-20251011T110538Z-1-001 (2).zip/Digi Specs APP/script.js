
// Example options data from an external source
const options = ["Laptop", "Smartphone", "Tablet", "Camera", "Smartwatch"];

document.addEventListener('DOMContentLoaded', function() {
    // Fetch laptops from the API
    fetch('http://localhost:3000/api/laptops')
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        const dropdown = document.getElementById('myDropdown');
        // dropdown.innerHTML = '';  // Clear previous options
        console.log(data)
        // Create default option
        const defaultOption = document.createElement('option');
        defaultOption.text = 'Select a Laptop';
        defaultOption.value = ""
        dropdown.appendChild(defaultOption);

        data.forEach(brand => {
            const option = document.createElement('option');
            option.value = brand.brandId; // Set value to brandID
            option.text = brand.brandname; // Set display text to brandName
            dropdown.appendChild(option);
        });
    })
    .catch(error =>
         console.error('Error fetching laptops:', error));
});

// Call the function on page load
// document.addEventListener('DOMContentLoaded', populateDropdown);

function toggleTableDisplay(){
    const dropdown = document.getElementById('myDropdown');
    const selectedBrandID = dropdown.value;
    if (selectedBrandID === "") {
        // Hide the table if no value is selected
        document.getElementById('brandTable').style.display = 'none';
        return;
    } 
}
function displaySelectedDetails() {

    const dropdown = document.getElementById('myDropdown');
    const selectedBrandID = dropdown.value;
    console.log(selectedBrandID)
    if (selectedBrandID === "") {
        // Hide the table if no value is selected
        document.getElementById('brandTable').style.display = 'none';
        alert('Please Select Model from Dropdown')
        return;
    }

    // Show the table if a value is selected
  
    // Fetch the selected brand details from an API (simulate with a local array)
     fetch('http://localhost:3000/api/getModelDetails',{
        method: 'POST', // Use POST to send data
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ modelID: selectedBrandID }) 
     }).then(response => response.json())
        .then(brandDetails => {
            console.log(brandDetails)
            console.log(brandDetails.length)
            if(brandDetails.message){
                document.getElementById('brandTable').style.display = 'none';
                alert('No Details Found')
                return
            }
            document.getElementById('brandTable').style.display = 'table';

            const tableBody = document.querySelector("#brandTable tbody");
            tableBody.innerHTML = ""; // Clear existing rows
            brandDetails.forEach(item=>{
                const row = document.createElement('tr');
                const nameCell = document.createElement('td');
                const processorCell = document.createElement('td');
                const ramCell = document.createElement('td');
                const storageCell = document.createElement('td');
                const screenresolutioncell = document.createElement('td');
                const processortypeCell = document.createElement('td');
    
                // idCell.textContent = brandDetails.id;
                nameCell.textContent = item.model;
                processorCell.textContent = item.processor;
                ramCell.textContent = item.ram;
                storageCell.textContent = item.storage;
                screenresolutioncell.textContent = item.screen_resolution;
                processortypeCell.textContent = item.Processor_type;
    
                row.appendChild(nameCell);
                row.appendChild(processorCell);
                row.appendChild(ramCell);
                row.appendChild(storageCell);
                row.appendChild(screenresolutioncell);
                row.appendChild(processortypeCell);
                tableBody.appendChild(row);
            })
           

        })
        .catch(error => console.error('Error fetching brand details:', error));
}
