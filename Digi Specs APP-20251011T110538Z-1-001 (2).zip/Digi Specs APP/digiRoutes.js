const express = require('express');
const router = express.Router();
const db = require('./server'); // Importing db connection from server.js

// Fetch all laptops
router.get('/laptops', (req, res) => {
    console.log('in fetchS')
    const sql = 'SELECT * FROM my_gaming_db.brands';
    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        console.log('in fetcprinthS',results)
        res.json(results);
    });
});
router.post('/getModelDetails', (req, res) => {

    const { modelID } = req.body; // Extract modelID from the request body
    const sql = 'SELECT * FROM my_gaming_db.laptops WHERE brandId = ?';

    db.query(sql, [modelID], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'No details found for this model' });
        }
        res.json(results); // Send the model details as response
    });
});
module.exports = router;
